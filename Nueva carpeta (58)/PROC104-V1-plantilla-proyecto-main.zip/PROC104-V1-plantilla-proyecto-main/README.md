# PROC104-V1-plantilla-proyecto
Plantilla del alumno.  
Nombra los planetas.  
Imagen a editar.  

### Texto en inglés: PRO-104-Project-Image
